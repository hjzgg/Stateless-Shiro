ESAPI2.0-ciphertext-portable.ser is a test for the backwards compatibility
of ESAPI 2.1.x and later crypto with ESAPI 2.0 crypto.

The file was created on Windows using the 128-bit test key from
Encryptor.MasterKey and encrypted with AES/CBC/PKCS5Padding.
